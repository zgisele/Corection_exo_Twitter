require 'twitter' # appelle de la gem twitter
require 'dotenv'# Appelle la gem Dotenv

require_relative './journalists.rb' # require journalists.rb file where located in head repository

Dotenv.load('../.env') # Ceci appelle le fichier .env (situé dans le même dossier que celui d'où tu exécute app.rb)
# et grâce à la gem Dotenv, on importe toutes les données enregistrées dans un hash ENV

# Il est ensuite très facile d'appeler les données du hash ENV, par exemple là je vais afficher le contenu de la clé TWITTER_API_SECRET
#puts ENV['TWITTER_API_SECRET']

#Autre exemple 
#puts ENV['BEST_WEBSITE_EVER']



def initializing
	@journalits = journalists
	@client = login_twitter
	@client_stream = login_twitter_stream
	@hashtag = "#bonjour_monde"
	@etp4a = "@edu_tech_platform_4_africa"
end 

def login_twitter
# quelques lignes qui appellent les clés d'API de ton fichier .env
	client = Twitter::REST::Client.new do |config|
  		config.consumer_key        = ENV["TWITTER_CONSUMER_KEY"]
  		config.consumer_secret     = ENV["TWITTER_CONSUMER_SECRET"]
  		config.access_token        = ENV["TWITTER_ACCESS_TOKEN"]
  		config.access_token_secret = ENV["TWITTER_ACCESS_TOKEN_SECRET"]
	end

#retourne le client
	return client
end

def login_twitter_stream
  	client_stream = Twitter::Streaming::Client.new do |config|
    config.consumer_key        = ENV["TWITTER_CONSUMER_KEY"]
    config.consumer_secret     = ENV["TWITTER_CONSUMER_SECRET"]
    config.access_token        = ENV["TWITTER_ACCESS_TOKEN"]
    config.access_token_secret = ENV["TWITTER_ACCESS_TOKEN_SECRET"]
  end
  return client_stream
end

def say_hello
journalists.sample(5).each do |i|
    @client.update("#{i} Merci pour votre travail ! #{@etp4a} #{@hashtag}") # ligne qui permet de tweeter sur ton compte
    puts"#{i}"
  end
end

def like_hello
  @client.search("#{@hashtag}", result_type: "recent").take(25).collect do |tweet|
    @client.favorite(tweet)
    puts "@#{tweet.user.screen_name} : #{tweet.text}"
  end
end

def follow_hello
  @client.search("#{@hashtag}", result_type: "recent").take(25).collect do |tweet|
    unless tweet.user == @client.user || @client.friends.include?(tweet.user)
      @client.follow(tweet.user)
      puts "@#{tweet.user.screen_name}"
    end
  end
end

def stream_hello
  @client_stream.filter(track: "#{@hashtag}") do |tweet|
    unless tweet.user == @client.user
    @client.favorite(tweet)
    @client.follow(tweet.user)
    puts "@#{tweet.user.screen_name} : #{tweet.text}"
    end
  end
end

def perform
  initializing
  like_hello
end
perform 





